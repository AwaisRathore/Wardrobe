<h1>Welcome to virtual wardrobe system</h1>
<br>
<a href="<?= site_url('Accounts') ?>">Login</a>